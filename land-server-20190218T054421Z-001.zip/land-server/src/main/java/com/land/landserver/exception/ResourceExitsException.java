/**
 * 
 */
package com.land.landserver.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * @author LB
 *
 */
@ResponseStatus(value = HttpStatus.CONFLICT)
public class ResourceExitsException extends RuntimeException {

  public ResourceExitsException() {
    super();
  }

  public ResourceExitsException(String message) {
    super(message);
  }
}

