/**
 * 
 */
package com.land.landserver.exception;

/**
 * @author LB
 *
 */
public class ResourceNotFoundException extends RuntimeException {
	
	public ResourceNotFoundException() {
		super();
	}

	public ResourceNotFoundException(String message) {
		super(message);
	}
}
